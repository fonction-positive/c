//Exe3.2
#include <stdio.h>
#include <stdlib.h>
#include "StructGraphe.h"

ListeAdj createListeA(int n);
Liste inserTete(Liste l,int s);
Liste init();
int nbsom(ListeAdj la);
int estBoucle(ListeAdj la);
void somSucce(int s,ListeAdj la);
int MaxSomSucce(ListeAdj la);

ListeAdj createListeA(int n){
    ListeAdj la;
    int i=0;
    la.nbsom=n;
    la.tab=(Liste*)malloc(n*sizeof(Liste));
    if(la.tab==NULL){
        printf("Memory allocation faild");
        exit(1);
    }
    for(i=0;i<n;i++){
        la.tab[i]=NULL;
    }
    return la;
}

Liste inserTete(Liste l,int s){
    Liste cel=(Liste)malloc(sizeof(Liste));
    cel->SomSucce=s;
    cel->suivant=l;
    l=cel;
    return l;
}

Liste init(){
    return NULL;
}

int nbsom(ListeAdj la){
    return la.nbsom;
}

int estBoucle(ListeAdj la){
    int n=nbsom(la);
    int s=0;
    int estBoucle=0;
    Liste ll;
    while (s<n && estBoucle==0){
        ll=la.tab[s];
        while (ll!=NULL && estBoucle==0){
            if(ll->SomSucce==s){
                estBoucle=1;
            }
            ll=ll->suivant;
        }
        s=s+1;
    }
    return estBoucle;
}

void somSucce(int s,ListeAdj la){
    Liste ll;
    ll=la.tab[s];
    printf("Les somme success de %d sont: \n",s);
    while (ll!=NULL){
        printf("%d ",ll->SomSucce);
        ll=ll->suivant;
    }
}

int MaxSomSucce(ListeAdj la){
    int n=nbsom(la);
    int MaxSom=0;
    int Max=0;
    int i=0,lg=0;
    Liste ll;
    for(i=0;i<n;i++){
        ll=la.tab[i];
        while (ll!=NULL){
            lg++;
            ll=ll->suivant;
        }
        if(lg>Max){
            Max=lg;
            MaxSom=i;
        }
        lg=0;
    }
    return MaxSom;
}

int main(void){
    ListeAdj la;
    int s=0;
    la=createListeA(5);
    Liste l=init();
    l=inserTete(l,2);
    la.tab[1]=l;
    l=init();
    l=inserTete(l,4);
    l=inserTete(l,3);
    la.tab[2]=l;
    printf("EstBoucle? %d\n",estBoucle(la));
    s=MaxSomSucce(la);
    somSucce(s,la);
    return 0;
}