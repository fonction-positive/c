#include <stdio.h>
#include <stdlib.h>
#include "StructGraphe.h"

//Exe4.6
MatriceIncid createMatriceIncid(int n,int p){
    MatriceIncid mi;
    int i,j;
    mi.nbArc=p;
    mi.nbSom=n;
    mi.mat=(int**)malloc(n*sizeof(int*));
    if(mi.mat==NULL){
        printf("eurro1!");
        exit(1);
    }
    for(i=0;i<n;i++){
        mi.mat[i]=(int*)malloc(p*sizeof(int));
        if(mi.mat[i]==NULL){
            printf("eurro2!");
            exit(1);
        }
    }
    for(i=0;i<n;i++){
        for(j=0;j<p;j++){
            mi.mat[i][j]=0;
        }
    }
    return mi;
}

MatriceIncid Ma2Mi(MatriceAdj ma){
    int n=ma.nbsom;
    int s,t;
    int p=0;
    for(s=0;s<n;s++){
        for(t=0;t<n;t++){
            if(ma.mat[s][t]==1){
                p++;
            }
        }
    }
    MatriceIncid mi=createMatriceIncid(n,p);
    int a=0;
    for(s=0;s<n;s++){
        for(t=0;t<n;t++){
            if(ma.mat[s][t]==1){
                mi.mat[s][a]=1;
                mi.mat[t][a]=-1;
                a++;
            }
        }
    }
    return mi;
}

// 打印邻接矩阵
void printMatriceAdj(MatriceAdj ma) {
    for (int i = 0; i < ma.nbsom; i++) {
        for (int j = 0; j < ma.nbsom; j++) {
            printf("%d ", ma.mat[i][j]);
        }
        printf("\n");
    }
}

// 打印关联矩阵
void printMatriceIncid(MatriceIncid mi) {
    printf("Matrix Incidence:\n");
    for (int i = 0; i < mi.nbArc; i++) {
        for (int j = 0; j < mi.nbSom; j++) {
            printf("%d ", mi.mat[j][i]);
        }
        printf("\n");
    }
}

int main() {
    // 创建邻接矩阵（一个简单的有向图）
    MatriceAdj ma;
    ma.nbsom = 4;  // 图有 4 个节点
    ma.mat = (int**)malloc(ma.nbsom * sizeof(int*));
    for (int i = 0; i < ma.nbsom; i++) {
        ma.mat[i] = (int*)malloc(ma.nbsom * sizeof(int));
    }

    // 初始化邻接矩阵
    // 图的边：0 -> 1, 1 -> 2, 2 -> 3, 3 -> 0
    ma.mat[0][1] = 1;  // 0 -> 1
    ma.mat[1][2] = 1;  // 1 -> 2
    ma.mat[2][3] = 1;  // 2 -> 3

    // 打印邻接矩阵
    printf("Adjacency Matrix (MatriceAdj):\n");
    printMatriceAdj(ma);

    // 将邻接矩阵转换为关联矩阵
    MatriceIncid mi = Ma2Mi(ma);

    // 打印关联矩阵
    printf("\nConverted Incidence Matrix (MatriceIncid):\n");
    printMatriceIncid(mi);

    // 释放内存
    for (int i = 0; i < ma.nbsom; i++) {
        free(ma.mat[i]);
    }
    free(ma.mat);

    for (int i = 0; i < mi.nbSom; i++) {
        free(mi.mat[i]);
    }
    free(mi.mat);

    return 0;
}