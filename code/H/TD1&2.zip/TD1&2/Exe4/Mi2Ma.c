#include <stdio.h>
#include <stdlib.h>
#include "StructGraphe.h"

MatriceAdj createMatriceAdj(int n){
    MatriceAdj ma;
    ma.nbsom=n;
    int i,j;
    ma.mat=(int**)malloc(n*sizeof(int*));
    if(ma.mat==NULL){
        printf("eurro1!");
        exit(1);
    }
    for(i=0;i<n;i++){
        ma.mat[i]=(int*)malloc(n*sizeof(int));
        if(ma.mat[i]==NULL){
            printf("eurro2!");
            exit(1);
        }
    }
    for(i=0;i<n;i++){
        for(j=0;j<n;j++){
            ma.mat[i][j]=0;
        }
    }
    return ma;
}

MatriceAdj Mi2Ma(MatriceIncid mi){
    int n=mi.nbSom;
    int p=mi.nbArc;
    MatriceAdj ma=createMatriceAdj(n);
    int a=0,s=0,t=0,u=0;
    for(a=0;a<p;a++){
        s=0;
        t=0;
        u=0;
        while (s*t==0){
            if(mi.mat[u][a]==1){
                s=u;
            }
            if(mi.mat[u][a]==-1){
                t=u;
            }
            u++;
        }
        ma.mat[s][t]=1;
    }
    return ma;
}

// 测试主函数
int main() {
    // 示例的 Incidence Matrix
    MatriceIncid mi;
    mi.nbSom = 4;  // 4 个节点
    mi.nbArc = 4;  // 4 条边
    mi.mat = (int**)malloc(4 * sizeof(int*));
    for (int i = 0; i < 4; i++) {
        mi.mat[i] = (int*)malloc(4 * sizeof(int));  // 每个节点有 4 条边
    }

    // 初始化 Incidence Matrix
    mi.mat[0][0] = 1;  
    mi.mat[0][1] = -1; 
    mi.mat[0][2] = 0; 
    mi.mat[0][3] = 0;
    mi.mat[1][0] = -1; 
    mi.mat[1][1] = 0;  
    mi.mat[1][2] = 1; 
    mi.mat[1][3] = 0;
    mi.mat[2][0] = 0;  
    mi.mat[2][1] = 1;  
    mi.mat[2][2] = 0; 
    mi.mat[2][3] = 0;
    mi.mat[3][0] = 0;  
    mi.mat[3][1] = 0;  
    mi.mat[3][2] = 0; 
    mi.mat[3][3] = 1;

    // 从 Incidence Matrix 转换到 Adjacency Matrix
    MatriceAdj ma = Mi2Ma(mi);

    // 打印邻接矩阵
    printf("Adjacency Matrix:\n");
    for (int i = 0; i < ma.nbsom; i++) {
        for (int j = 0; j < ma.nbsom; j++) {
            printf("%d ", ma.mat[i][j]);
        }
        printf("\n");
    }

    // 释放内存
    for (int i = 0; i < mi.nbArc; i++) {
        free(mi.mat[i]);
    }
    free(mi.mat);

    for (int i = 0; i < ma.nbsom; i++) {
        free(ma.mat[i]);
    }
    free(ma.mat);

    return 0;
}