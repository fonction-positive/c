#include <stdio.h>
#include <stdlib.h>
#include "StructGraphe.h"

//Exe4.5
FileSucce createFileSucce(int nbsom, int nbarc) {
    FileSucce fs;
    fs.nbSom = nbsom;
    fs.nbArcs = nbarc;

    // 分配内存
    fs.APS = (int*)malloc((nbsom + 1) * sizeof(int));
    if (fs.APS == NULL) {
        printf("Memory allocation failed for APS.\n");
        exit(1);  // 内存分配失败，退出程序
    }

    fs.FS = (int*)malloc(nbarc * sizeof(int));
    if (fs.FS == NULL) {
        printf("Memory allocation failed for FS.\n");
        free(fs.APS);  // 释放之前分配的内存
        exit(1);
    }

    return fs;
}

FileSucce La2Fs(ListeAdj la){
    int n=la.nbsom;
    int p=0,s=0;
    Liste ll;
    for(s=0;s<n;s++){
        ll=la.tab[s];
        while(ll!=NULL){
            p++;
            ll=ll->suivant;
        }
    }
    FileSucce fs=createFileSucce(n,p);
    int iAps=0;
    for(s=0;s<n;s++){
        fs.APS[s]=iAps;
        ll=la.tab[s];
        while (ll!=NULL){
            fs.FS[iAps]=ll->SomSucce;
            iAps++;
            ll=ll->suivant;
        }
    }
    fs.APS[n]=p;
    return fs;
}

// 插入元素到链表头部
Liste inserTete(Liste l, int s) {
    Liste cel = (Liste)malloc(sizeof(struct cellul));
    cel->SomSucce = s;
    cel->suivant = l;
    l = cel;
    return l;
}

// 打印 FileSucce 结构体内容
void printFileSucce(FileSucce fs) {
    printf("Number of nodes: %d\n", fs.nbSom);
    printf("Number of arcs: %d\n", fs.nbArcs);

    printf("APS: ");
    for (int i = 0; i <= fs.nbSom; i++) {
        printf("%d ", fs.APS[i]);
    }
    printf("\n");

    printf("FS: ");
    for (int i = 0; i < fs.nbArcs; i++) {
        printf("%d ", fs.FS[i]);
    }
    printf("\n");
}

int main() {
    int n = 5; // 假设图有5个节点
    ListeAdj la;
    la.nbsom = n;

    // 创建邻接表，分配内存
    la.tab = (Liste*)malloc(n * sizeof(Liste));
    for (int i = 0; i < n; i++) {
        la.tab[i] = NULL;  // 初始化每个链表为空
    }

    // 构建邻接表（有向图示例）
    la.tab[0] = inserTete(la.tab[0], 1); // 0 -> 1
    la.tab[1] = inserTete(la.tab[1], 2); // 1 -> 2
    la.tab[2] = inserTete(la.tab[2], 3); // 2 -> 3
    la.tab[3] = inserTete(la.tab[3], 4); // 3 -> 4
    la.tab[4] = inserTete(la.tab[4], 0); // 4 -> 0

    // 打印原始邻接表
    printf("Adjacency List (La):\n");
    for (int i = 0; i < n; i++) {
        printf("Node %d: ", i);
        Liste l = la.tab[i];
        while (l != NULL) {
            printf("%d -> ", l->SomSucce);
            l = l->suivant;
        }
        printf("NULL\n");
    }

    // 转换为 FileSucce 格式
    FileSucce fs = La2Fs(la);

    // 打印 FileSucce 内容
    printFileSucce(fs);

    // 释放内存
    for (int i = 0; i < n; i++) {
        Liste current = la.tab[i];
        while (current != NULL) {
            Liste temp = current;
            current = current->suivant;
            free(temp);
        }
    }
    free(la.tab);
    free(fs.APS);
    free(fs.FS);

    return 0;
}