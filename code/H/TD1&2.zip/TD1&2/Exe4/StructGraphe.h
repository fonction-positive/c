#ifndef S_G_H
#define S_G_H
typedef struct{
    int nbSom;
    int nbArcs;
    int *FS;
    int *APS;
}FileSucce;

typedef struct{
    int nbsom;
    int ** mat;
}MatriceAdj;

typedef struct cellul{
    int SomSucce;
    struct cellul * suivant;
}* Liste;

typedef struct{
    int nbsom;
    Liste* tab;
}ListeAdj;

typedef struct {
    Liste ListeSucce;
    Liste ListePrece;
}SP;

typedef struct{
    int nbSom;
    SP* tab;
}ListeSP;

typedef struct{
    int nbArc;
    int nbSom;
    int** mat;
}MatriceIncid;
#endif
