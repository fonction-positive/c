#include <stdio.h>
#include <stdlib.h>
#include "StructGraphe.h"

//Exe4.1
ListeAdj createListeA(int n){
    ListeAdj la;
    int i=0;
    la.nbsom=n;
    la.tab=(Liste*)malloc(n*sizeof(Liste));
    if(la.tab==NULL){
        printf("Memory allocation faild");
        exit(1);
    }
    for(i=0;i<n;i++){
        la.tab[i]=NULL;
    }
    return la;
}

Liste inserTete(Liste l,int s){
    Liste cel=(Liste)malloc(sizeof(Liste));
    cel->SomSucce=s;
    cel->suivant=l;
    l=cel;
    return l;
}

Liste init(){
    return NULL;
}

ListeAdj Ma2La(MatriceAdj ma){
    int n=ma.nbsom;
    ListeAdj la=createListeA(n);
    int s=0,t=0;
    Liste l;
    for(s=0;s<n;s++){
        l=init();
        for(t=n-1;t>=0;t--){
            if(ma.mat[s][t]==1){
                l=inserTete(l,t);
            }
        }
        la.tab[s]=l;
    }
    return la;
}

// 打印邻接链表
void printListe(Liste l) {
    while (l != NULL) {
        printf("%d -> ", l->SomSucce);
        l = l->suivant;
    }
    printf("NULL\n");
}

int main() {
    // 创建一个邻接矩阵
    int n = 5;  // 假设图有 5 个节点
    MatriceAdj ma;
    ma.nbsom = n;
    
    // 分配内存并初始化邻接矩阵
    ma.mat = (int**)malloc(n * sizeof(int*));
    for (int i = 0; i < n; i++) {
        ma.mat[i] = (int*)malloc(n * sizeof(int));
    }
    
    // 初始化邻接矩阵 (图的结构)
    // 假设一个简单的有向图
    // 0 -> 1, 1 -> 2, 2 -> 3, 3 -> 4, 4 -> 0
    ma.mat[0][1] = 1;
    ma.mat[1][2] = 1;
    ma.mat[2][3] = 1;
    ma.mat[3][4] = 1;
    ma.mat[4][0] = 1;
    
    // 转换为邻接链表
    ListeAdj la = Ma2La(ma);
    
    // 打印邻接链表
    printf("Adjacency List:\n");
    for (int i = 0; i < n; i++) {
        printf("Node %d: ", i);
        printListe(la.tab[i]);
    }

    // 释放内存
    for (int i = 0; i < n; i++) {
        Liste current = la.tab[i];
        while (current != NULL) {
            Liste temp = current;
            current = current->suivant;
            free(temp);
        }
    }
    free(la.tab);
    
    for (int i = 0; i < n; i++) {
        free(ma.mat[i]);
    }
    free(ma.mat);

    return 0;
}