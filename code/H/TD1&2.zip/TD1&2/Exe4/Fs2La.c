#include <stdio.h>
#include <stdlib.h>
#include "StructGraphe.h"

//Exe4.4
ListeAdj createListeA(int n){
    ListeAdj la;
    int i=0;
    la.nbsom=n;
    la.tab=(Liste*)malloc(n*sizeof(Liste));
    if(la.tab==NULL){
        printf("Memory allocation faild");
        exit(1);
    }
    for(i=0;i<n;i++){
        la.tab[i]=NULL;
    }
    return la;
}

Liste inserTete(Liste l,int s){
    Liste cel=(Liste)malloc(sizeof(Liste));
    cel->SomSucce=s;
    cel->suivant=l;
    l=cel;
    return l;
}

Liste init(){
    return NULL;
}

ListeAdj Fs2La(FileSucce fs){
    int n=fs.nbSom;
    ListeAdj la=createListeA(n);
    int s,j,t;
    Liste l;
    int nbSucc,daps;
    for(s=0;s<n;s++){
        l=init();
        nbSucc=fs.APS[s+1]-fs.APS[s];
        daps=fs.APS[s+1]-1;
        for(j=0;j<nbSucc;j++){
            t=fs.FS[daps];
            daps--;
            l=inserTete(l,t);
        }
        la.tab[s]=l;
    }
    return la;
}

// 打印邻接表
void printListeAdj(ListeAdj la) {
    for (int i = 0; i < la.nbsom; i++) {
        printf("Node %d: ", i);
        Liste l = la.tab[i];
        while (l != NULL) {
            printf("%d -> ", l->SomSucce);
            l = l->suivant;
        }
        printf("NULL\n");
    }
}

// 打印 FileSucce 结构体
void printFileSucce(FileSucce fs) {
    printf("Number of nodes: %d\n", fs.nbSom);
    printf("Number of arcs: %d\n", fs.nbArcs);

    printf("APS: ");
    for (int i = 0; i <= fs.nbSom; i++) {
        printf("%d ", fs.APS[i]);
    }
    printf("\n");

    printf("FS: ");
    for (int i = 0; i < fs.nbArcs; i++) {
        printf("%d ", fs.FS[i]);
    }
    printf("\n");
}

int main() {
    // 创建一个 FileSucce 格式的图
    FileSucce fs;
    fs.nbSom = 5;
    fs.nbArcs = 5;

    // 分配 APS 和 FS 数组
    fs.APS = (int*)malloc((fs.nbSom + 1) * sizeof(int));
    fs.FS = (int*)malloc(fs.nbArcs * sizeof(int));

    // 初始化 APS 和 FS 数组
    fs.APS[0] = 0;   // Node 0 starts at position 0 in FS
    fs.APS[1] = 1;   // Node 1 starts at position 1 in FS
    fs.APS[2] = 2;   // Node 2 starts at position 2 in FS
    fs.APS[3] = 3;   // Node 3 starts at position 3 in FS
    fs.APS[4] = 4;   // Node 4 starts at position 4 in FS
    fs.APS[5] = 5;   // Node 5 has no arcs, ends at position 5 in FS

    fs.FS[0] = 1;  // Node 0 -> Node 1
    fs.FS[1] = 2;  // Node 1 -> Node 2
    fs.FS[2] = 3;  // Node 2 -> Node 3
    fs.FS[3] = 4;  // Node 3 -> Node 4
    fs.FS[4] = 0;  // Node 4 -> Node 0

    // 打印 FileSucce 格式图
    printf("FileSucce format:\n");
    printFileSucce(fs);

    // 将 FileSucce 转换为邻接表
    ListeAdj la = Fs2La(fs);

    // 打印邻接表
    printf("\nConverted Adjacency List (ListeAdj):\n");
    printListeAdj(la);

    // 释放内存
    free(fs.APS);
    free(fs.FS);
    for (int i = 0; i < la.nbsom; i++) {
        Liste current = la.tab[i];
        while (current != NULL) {
            Liste temp = current;
            current = current->suivant;
            free(temp);
        }
    }
    free(la.tab);

    return 0;
}