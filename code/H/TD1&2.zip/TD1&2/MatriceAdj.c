//Exe3.1
#include <stdio.h>
#include <stdlib.h>
#include "StructGraphe.h"

MatriceAdj creatMatriceAdj(int n);
int nbsom(MatriceAdj m);
int estBoucle(MatriceAdj m);
void somSucce(int s,MatriceAdj m);
void somPredce(int s,MatriceAdj m);
int MaxSomSucce(MatriceAdj m);

MatriceAdj creatMatriceAdj(int n){
    MatriceAdj m;
    m.nbsom=n;
    int i=0;
    m.mat=(int**)malloc(n*sizeof(int*));
    if(m.mat==NULL){
        printf("Memory allocation failed");
        exit(1);
    }
    for(i=0;i<n;i++){
        m.mat[i]=(int*)malloc(n*sizeof(int));
        if(m.mat[i]==NULL){
            printf("Memory allocation failed for ligne");
            exit(1);
        }
    }
    return m;
}

int nbsom(MatriceAdj m){
    return m.nbsom;
}

int estBoucle(MatriceAdj m){
    int s=0;
    int n=nbsom(m);
    int flag=0;
    while(s<n && flag==0){
        if(m.mat[s][s]==1){
            flag=1;
        }
        s++;
    }
    return flag;
}

void somSucce(int s,MatriceAdj m){
    int i=0;
    int n=nbsom(m);
    printf("Les somme success de %d sont: \n",s);
    for(i=0;i<n;i++){
        if(m.mat[s][i]==1){
            printf("%d ",i);
        }
    }
    printf("\n");
}

void somPredce(int s,MatriceAdj m){
     int i=0;
    int n=nbsom(m);
    printf("Les somme predecesseurs de %d sont: \n",s);
    for(i=0;i<n;i++){
        if(m.mat[i][s]==1){
            printf("%d ",i);
        }
    }
    printf("\n");
}

int MaxSomSucce(MatriceAdj m){
    int MaxS=0;
    int MaxSucce=0;
    int SomSucce=0;
    int i=0,j=0;
    int n=nbsom(m);
    for(i=0;i<n;i++){
        for(j=0;j<n;j++){
            if(m.mat[i][j]==1){
                SomSucce++;
            }
        }
        if(SomSucce>MaxSucce){
            MaxSucce=SomSucce;
            MaxS=i;
        }
    }
    return MaxS;
}

int main(void){
    MatriceAdj m;
    int i=0,j=0,s=0;
    m=creatMatriceAdj(5);
    for(i=0;i<5;i++){
        for(j=0;j<5;j++){
            m.mat[i][j]=0;
        }
    }
    m.mat[2][3]=1;
    m.mat[1][2]=1;
    m.mat[2][4]=1;
    printf("EstBoucle? %d\n",estBoucle(m));
    s=MaxSomSucce(m);
    somSucce(s,m);
    somPredce(s,m);
    return 0;
}